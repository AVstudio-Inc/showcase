import{a as e}from"./editorApp-DZMui-50.js";const o=t=>(e.getState().envState==="build"?".":"")+t;export{o as c};
