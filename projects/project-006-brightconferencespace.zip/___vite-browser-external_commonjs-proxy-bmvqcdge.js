import{ar as e}from"./index-CR7MAnCp.js";const r={},t=Object.freeze(Object.defineProperty({__proto__:null,default:r},Symbol.toStringTag,{value:"Module"})),a=e(t);export{a as r};
