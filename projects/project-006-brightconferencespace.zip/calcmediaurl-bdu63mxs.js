import{a as e}from"./editorApp-DLWlunXz.js";const o=t=>(e.getState().envState==="build"?".":"")+t;export{o as c};
